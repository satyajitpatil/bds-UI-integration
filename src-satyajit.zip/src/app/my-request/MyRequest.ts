export interface MyRequest
{
    id:number;
    availableBloodId : number;
    bloodGroup : string;
    firstName: string;
    lastName:string;
    bloodBankName : string;    
    rejected:string;    
    pending:string;
    approved:string;
}