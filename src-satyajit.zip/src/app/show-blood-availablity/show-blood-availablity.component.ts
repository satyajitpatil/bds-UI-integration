import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-blood-availablity',
  templateUrl: './show-blood-availablity.component.html',
  styleUrls: ['./show-blood-availablity.component.css']
})
export class ShowBLoodAvailablityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
