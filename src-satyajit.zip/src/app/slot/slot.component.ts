import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { slot } from './slot';
import { SlotService } from '../service/slot.service';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-slot',
  templateUrl: './slot.component.html',
  styleUrls: ['./slot.component.css']
})
export class SlotComponent implements OnInit {
  public valid:boolean=false;
  appointmentForm: FormGroup;
  Slot :slot;
  slotBooked:number;

  constructor(private slotService : SlotService, private userService:UserService) { }

  ngOnInit() {
    this.appointmentForm= new FormGroup({
      HospitalName: new FormControl(''),
      City: new FormControl(''),
      Date: new FormControl(''),
      Time: new FormControl('')
    });
  }
  onSubmit()
  {
    console.log(this.appointmentForm);
    this.Slot={
      slotId:0,
      hospitalName:this.appointmentForm.value.HospitalName,
      city:this.appointmentForm.value.City,
      date:this.appointmentForm.value.Date,
      time:this.appointmentForm.value.Time,
      donorId :this.userService.user.userId
    }
    this.slotService.checkSlotAvailability(this.Slot).subscribe((res) => {this.slotBooked=res});
    if(this.slotBooked<3)
    {
      this.slotBooking(); 
    }
    else{
      console.log("SLots are not Available");
    }
    }
    slotBooking()
    {
      
      this.slotService.bookSlot(this.Slot).subscribe((res) => {console.log("success")});    
      return this.valid=true;
    }


    

}
