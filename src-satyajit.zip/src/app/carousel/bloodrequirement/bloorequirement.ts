export interface bloodrequirement{
    bloodRequestId : number;
    bloodGroup : string;
    firstName : string;
    lastName : string
    state : string;
    area :string;
    pincode :number;
    contactNumber : number;
    //bloodUnits : number;
    userId :number;
}