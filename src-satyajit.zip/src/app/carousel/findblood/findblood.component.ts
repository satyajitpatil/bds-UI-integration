import { Component, OnInit } from '@angular/core';
import { BloodAvailablityService } from 'src/app/service/blood-availablity.service';
import { findblood } from './findblood';
import { environment } from 'src/environments/environment.prod';
import { Subject } from 'rxjs';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-findblood',
  templateUrl: './findblood.component.html',
  styleUrls: ['./findblood.component.css']
})
export class FindbloodComponent implements OnInit { 

  availableBloodForm: FormGroup;
  availableBlood : findblood[];
  state:string;
  area:string;
  pincode:number;
  bloodGroup:string;
  constructor(private blood : BloodAvailablityService) { }

  ngOnInit() {
    this.availableBloodForm = new FormGroup({
      State: new FormControl(),
      Area: new FormControl(),
      Pincode: new FormControl(),
      BloodGroup: new FormControl()
    });

  }
  onclick()
  {

    this.state = this.availableBloodForm.value.State;
    this.area = this.availableBloodForm.value.Area;
    this.pincode = this.availableBloodForm.value.Pincode;
    this.bloodGroup = this.availableBloodForm.value.BloodGroup;
    //console.log(this.state+" "+this.area);
    //console.log(this.availableBlood);

    //depending on selection
    if(this.state!=null && this.area==null && this.bloodGroup==null){
      this.getAvailableBloodByState();
    }
    else if(this.state!=null && this.area!=null && this.bloodGroup==null){
      this.getAvailableBloodByStateAndArea();
    }
    else if(this.state==null && this.area==null && this.bloodGroup!=null){
      this.getAvailableBloodByBloodGroup();
    }
    else if(this.state!=null && this.area!=null && this.bloodGroup!=null){
      this.getAvailableBlood();
    }
    else{
      console.log("fill atleast state field");
    }
    
  }

  getAvailableBlood(){
    //this.availableBlood = this.blood.getAvailableBlood();
    this.blood.getAvailableBlood().subscribe((res) => this.availableBlood = res);
      this.blood.getSubject().subscribe((data) => {
        this.availableBlood = data;
      });
  }

  getAvailableBloodByState(){
    this.blood.getAvailableBloodByState(this.state).subscribe((res) => this.availableBlood = res);
      this.blood.getSubject().subscribe((data) => {
        this.availableBlood = data;
      });
  }
  getAvailableBloodByBloodGroup(){
    this.blood.getAvailableBloodByBloodGroup(this.bloodGroup).subscribe((res) => this.availableBlood = res);
      this.blood.getSubject().subscribe((data) => {
        this.availableBlood = data;
      });
  }
  getAvailableBloodByStateAndArea(){
    this.blood.getAvailableBloodByStateAndArea(this.state,this.area).subscribe((res) => this.availableBlood = res);
      this.blood.getSubject().subscribe((data) => {
        this.availableBlood = data;
      });
  }

  


}
