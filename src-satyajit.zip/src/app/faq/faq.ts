export interface faq {
    faqId: number;
    question: string;
    answer: string;
    answered: boolean;
    userId: number;
}