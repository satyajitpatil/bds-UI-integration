import { Component, OnInit } from '@angular/core';
import { BloodAvailablityService } from '../service/blood-availablity.service';
import { FaqService } from '../service/faq.service';
import { faq } from '../faq/faq';
import { UserService } from '../service/user.service';
import { BloodRequestService } from '../service/blood-request.service';
import { MyRequest } from '../my-request/myRequest';
import { MyRequestService } from '../service/my-request.service';
import { experience } from '../experience/experience';
import { FeedbackService } from '../service/feedback.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  totalUnits: number;
  totalDonors: number;
  totalBloodBanks: number;
  totalUnanswered: number;
  totalRequests: number;
  faq: faq[];
  isAdmin: boolean;
  isHospital: boolean;
  hospitalRequest: MyRequest[];
  feedbacks:experience[];

  constructor(private blood: BloodAvailablityService, private faqService: FaqService, private userService: UserService, private requestService: BloodRequestService, private requestStatusService: MyRequestService, private feedbackService:FeedbackService) { }

  ngOnInit() {
    this.updateDashboard();
  }

  updateDashboard() {

    this.isAdmin = this.userService.isAdmin;
    this.isHospital = this.userService.isHospital;
    /* hospitalRequest:fin */

    this.blood.getAvailableUnitsForAdmin("ALL").subscribe((res) => {
      this.totalUnits = res;
    });

    this.faqService.getUnAnsweredQuestion().subscribe((res) => {
      this.faq = res;
      this.totalUnanswered = this.faq.length;
    });

    this.userService.getNumberOfDonors().subscribe((res) => {
      this.totalDonors = res;
    });

    this.requestService.getTodaysRequest().subscribe((res) => {
      this.totalRequests = res;
    });

    this.requestStatusService.getHospitalRequest(1).subscribe((res) => {
      this.hospitalRequest = res;
    });

    this.getFeedbacks();
  }
  onAccept() {
    this.requestStatusService.accept().subscribe((res) => { console.log("approved") });
    this.updateDashboard();
  }
  onReject() {
    this.requestStatusService.reject().subscribe((res) => { console.log("rejected") });
    this.updateDashboard();
  }
  getFeedbacks(){
    this.feedbackService.getAllFeedback().subscribe((res)=>{
      this.feedbacks = res;
    });
  }

}
