import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-slot',
  templateUrl: './slot.component.html',
  styleUrls: ['./slot.component.css']
})
export class SlotComponent implements OnInit {
  issumitted = false;
  public valid: boolean = false;
  appointmentForm: FormGroup;

  HospitalName = '';
  City = '';
  Date;
  Time = '';

  constructor() { }

  ngOnInit() {
    this.appointmentForm = new FormGroup({
      HospitalName: new FormControl(this.HospitalName, [Validators.required]),
      City: new FormControl(this.City, [Validators.required]),
      Date: new FormControl(this.Date, [Validators.required]),
      Time: new FormControl(this.Time, [Validators.required])
    });


  }
  get f() {
    return this.appointmentForm.controls;
  }
  onsubmit() {
    this.issumitted = true;
    console.log(this.appointmentForm.value)

    if (this.appointmentForm.invalid) {

      return;
    }


    this.valid = true;

  }


}
