import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SlotService {

  
  isAdmin:boolean;
  isLoggedIn:boolean;

  constructor() { }
}
