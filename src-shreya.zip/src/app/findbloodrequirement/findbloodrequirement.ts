export interface findbloodrequirement{
    bloodRequestId : number;
    bloodGroup : string;
    hospitalName : string;
    state : string;
    area :string;
    pincode :number;
    contactNumber : number;
    bloodUnits : number;
    fulfilled : boolean;
    userId :number;
}