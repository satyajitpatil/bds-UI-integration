import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FindbloodrequirementComponent } from './findbloodrequirement.component';

describe('FindbloodrequirementComponent', () => {
  let component: FindbloodrequirementComponent;
  let fixture: ComponentFixture<FindbloodrequirementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FindbloodrequirementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FindbloodrequirementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
