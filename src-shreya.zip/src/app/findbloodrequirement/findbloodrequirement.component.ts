import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { findbloodrequirement } from './findbloodrequirement';
@Component({
  selector: 'app-findbloodrequirement',
  templateUrl: './findbloodrequirement.component.html',
  styleUrls: ['./findbloodrequirement.component.css']
})
export class FindbloodrequirementComponent implements OnInit {
  issumitted: boolean = false;
  success: boolean = false;
  findbloodrequirementForm: FormGroup;
  findrequiredBlood: findbloodrequirement[];

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.findbloodrequirementForm = this.formBuilder.group({
      State: new FormControl('', [Validators.required]),
      Area: new FormControl('', [Validators.required]),
      Pincode: new FormControl('', [Validators.required, Validators.minLength(6)]),
      BloodGroup: new FormControl('', [Validators.required]),
    });
  }
  OnSubmit() {
    this.issumitted = true;

    if (this.findbloodrequirementForm.invalid) {
      return;
    }

    this.success = true;

    console.log(this.issumitted);
  }

  get f() {
    return this.findbloodrequirementForm.controls;
  }
}
