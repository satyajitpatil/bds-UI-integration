export interface MyRequest
{
    id:number;
    availableBloodId : number;
    bloodGroup : string;
    bloodBankName : string;
    isApproved:boolean;
    isRejected:boolean;
    bloodUnits : number;
}