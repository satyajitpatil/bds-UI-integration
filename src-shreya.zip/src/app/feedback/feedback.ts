export interface feedbackrequirement
{
    comment :string;
    userId : number;
}