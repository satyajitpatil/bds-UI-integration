import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl} from '@angular/forms';

@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.css']
})
export class AppointmentComponent implements OnInit {
public valid:boolean=false;
appointmentForm: FormGroup;
  constructor() { }

  ngOnInit() {
    this.appointmentForm= new FormGroup({
      HospitalName: new FormControl(),
      City: new FormControl(),
      Date: new FormControl(),
      Time: new FormControl()
    });
  }
  onSubmit()
  {
    return this.valid=true;
    console.log(this.appointmentForm)
  }

}
