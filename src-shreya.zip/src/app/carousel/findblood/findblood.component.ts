import { Component, OnInit } from '@angular/core';
import { BloodAvailablityService } from 'src/app/service/blood-availablity.service';
import { findblood } from './findblood';
import { environment } from 'src/environments/environment.prod';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-findblood',
  templateUrl: './findblood.component.html',
  styleUrls: ['./findblood.component.css']
})
export class FindbloodComponent implements OnInit { 


  notAvailable =true;

  availableBlood : findblood[];
  constructor(private blood : BloodAvailablityService) { }

  ngOnInit() {
    /* this.availableBlood = this.blood.getAvailableBlood(); */
  }
  onclick()
  {
    console.log(this.availableBlood);
    //this.availableBlood = this.blood.getAvailableBlood();
    this.blood.getAvailableBlood().subscribe((res) => this.availableBlood = res);
      this.blood.getSubject().subscribe((data) => {
        this.availableBlood = data;
      });
  }


}
