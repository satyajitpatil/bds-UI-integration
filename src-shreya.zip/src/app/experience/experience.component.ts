import { Component, OnInit } from '@angular/core';
import { FeedbackService } from '../service/feedback.service';
import { experience } from './experience';
import { NgForm, FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-experience',
  templateUrl: './experience.component.html',
  styleUrls: ['./experience.component.css']
})
export class ExperienceComponent implements OnInit {
  availableExperience : experience[];
submitted = false;
success = false;
  postFeedback : experience;
  experienceForm: FormGroup;

  constructor(private feedbackService : FeedbackService) { }

  ngOnInit() {
    this.experienceForm= new FormGroup({
      HospitalName: new FormControl('',[Validators.required]),
      City: new FormControl('',[Validators.required]),
      Comment: new FormControl('', [Validators.required])
    });

  }
  onclick()
  {
    console.log(this.availableExperience);
    //this.availableBlood = this.blood.getAvailableBlood();
    this.feedbackService.getAllFeedback().subscribe((res) => this.availableExperience = res);
      this.feedbackService.getSubject().subscribe((data) => {
        this.availableExperience = data;  
      });
    }

    get f(){
      return this.experienceForm.controls;
    }

    onSubmit(){
this.submitted = true;
      console.log(this.experienceForm.value);

      if(this.experienceForm.invalid){
        return;
      }

      this.success = true;
 
      this.postFeedback={
        hospitalName:this.experienceForm.value.HospitalName,
        city:this.experienceForm.value.City,
        comment:this.experienceForm.value.Comment,
        userId:1
      }
      this.feedbackService.postFeedback(this.postFeedback).subscribe((res)=>{console.log("SUCCESS")});
      console.log(this.postFeedback);
}
}
