export interface register
{
   faqId:number;
    question:string;
    answer:string;
    userId:number;
}